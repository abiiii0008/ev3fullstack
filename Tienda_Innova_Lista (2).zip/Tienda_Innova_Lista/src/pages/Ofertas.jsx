// src/pages/Ofertas.jsx
import React, { useEffect, useState } from "react";
import { getAllProducts } from "../data/data";
// Importamos el Footer
import Footer from "../components/Footer"; 

export default function Ofertas(){
  const [products, setProducts] = useState([]);
  useEffect(()=> setProducts(getAllProducts().filter(p => p.category && p.category.toLowerCase().includes('oferta'))), []);
  return (
    <>
      <div className="container mt-4"> {}
        <h2 className="text-neon">Ofertas</h2>
        <div className="row">
          {products.length===0 && <p>No hay ofertas por ahora.</p>}
          {products.map(p=>(
            <div key={p.id} className="col-md-4 mb-3">
              <div className="card">
                <div className="card-body">
                  <h5>{p.title}</h5>
                  <p>{p.description}</p>
                  <p><strong>${p.price}</strong></p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </>
  );
}