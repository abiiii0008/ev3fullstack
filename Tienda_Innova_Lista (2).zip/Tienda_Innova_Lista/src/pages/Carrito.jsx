// src/pages/Carrito.jsx
import React from "react";
import { useCart } from "../context/CartContext";
import { Link, useNavigate } from "react-router-dom";
// 1. Importamos el componente Footer
import Footer from "../components/Footer"; 

export default function Carrito() {
  const { cart, total, removeFromCart, updateQuantity, clearCart } = useCart();
  const navigate = useNavigate();

  function onCheckout() {
    navigate('/checkout');
  }

  if (!cart || cart.length === 0) {
    return (
        
        <>
            <div className="container mt-4">
                <h2 className="text-neon">Carrito</h2>
                <div className="alert alert-info">Tu carrito está vacío. <Link to="/productos">Agregar productos</Link></div>
            </div>
            {}
            <Footer />
        </>
    );
  }

  return (
    
    <>
        <div className="container mt-4">
          <h2 className="text-neon">Carrito</h2>
          <div className="list-group mb-3">
            {cart.map(item => (
              <div key={item.id} className="list-group-item d-flex justify-content-between align-items-center">
                <div>
                  <strong className="text-neon">{item.name}</strong>
                  <div className="text-muted">Precio: ${item.price.toLocaleString('es-CL')}</div>
                </div>
                <div className="d-flex align-items-center gap-2">
                  <input type="number" min="1" value={item.quantity} onChange={(e)=> updateQuantity(item.id, Number(e.target.value))} style={{width:80}} className="form-control form-control-sm"/>
                  <button className="btn btn-outline-danger btn-sm" onClick={()=> removeFromCart(item.id)}>Eliminar</button>
                </div>
              </div>
            ))}
          </div>

          <div className="d-flex justify-content-between align-items-center">
            <strong>Total: ${total.toLocaleString('es-CL')}</strong>
            <div>
              <button className="btn btn-secondary me-2" onClick={()=> { clearCart(); }}>Vaciar carrito</button>
              <button className="btn btn-success" onClick={onCheckout}>Proceder al checkout</button>
            </div>
          </div>
        </div>
        {}
        <Footer />
    </>
  );
}