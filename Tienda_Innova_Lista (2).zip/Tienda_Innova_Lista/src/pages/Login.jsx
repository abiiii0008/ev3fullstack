// src/pages/Login.jsx
import React,{useState} from 'react'; 
import { useAuth } from '../context/AuthContext'; 
import { useNavigate, useLocation } from 'react-router-dom'; 
// Importamos el Footer
import Footer from "../components/Footer"; 

export default function Login(){ 
    const {login}=useAuth(); 
    const navigate=useNavigate(); 
    const location=useLocation(); 
    const from=location.state?.from?.pathname||'/'; 
    const [form,setForm]=useState({email:'',password:''}); 
    const [err,setErr]=useState(null); 
    const [loading,setLoading]=useState(false); 
    
    function onChange(e){ 
        setForm(p=>({...p,[e.target.name]:e.target.value})); 
    } 
    
    async function onSubmit(e){ 
        e.preventDefault(); 
        setErr(null); 
        setLoading(true); 
        try{ 
            await login({email:form.email,password:form.password}); 
            navigate(from,{replace:true}); 
        }catch(err){ 
            setErr(err.message||'Error'); 
        } finally{ 
            setLoading(false); 
        } 
    } 
    
    return (
        <>
            <div className='container mt-5'>
                <h2 className='text-neon'>Iniciar sesión</h2>
                <form onSubmit={onSubmit} style={{maxWidth:520}}>
                    {err && <div className='alert alert-danger'>{err}</div>}
                    <div className='mb-3'>
                        <label className='form-label'>Email</label>
                        <input name='email' type='email' className='form-control' value={form.email} onChange={onChange} required/>
                    </div>
                    <div className='mb-3'>
                        <label className='form-label'>Contraseña</label>
                        <input name='password' type='password' className='form-control' value={form.password} onChange={onChange} required/>
                    </div>
                    <button className='btn btn-primary' type='submit' disabled={loading}>
                        {loading? 'Verificando...':'Entrar'}
                    </button>
                </form>
            </div>
            <Footer />
        </>
    ); 
}