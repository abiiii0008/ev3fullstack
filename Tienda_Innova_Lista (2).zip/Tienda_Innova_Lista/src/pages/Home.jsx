// src/pages/Home.jsx
import React from 'react';
import { Link } from "react-router-dom"; // Importamos Link para navegación interna
import Footer from "../components/Footer";

export default function Home() {
    const blogs = [
        {
            id: 1,
            titulo: "Review del teclado Redragon Kumara K552: ¿el mejor para programadores?",
            descripcion: "Si hay algo que no podemos cuestionar como programadores, es que nuestro periférico más importante y favorito es el teclado. Con él escribimos el código que paga nuestras cuentas a final de mes, por lo que es preciso saber cuál elegir al momento de adquirir uno, y en este artículo traigo una review sobre la mejor opción calidad-precio que conozco de primera mano: el Redragon Kumara K552.",
            imagen: "https://www.esquinadelcodigo.com/_next/image?url=https%3A%2F%2Fa-us.storyblok.com%2Ff%2F1005258%2F1234x526%2F9d7b830c91%2Fcover.png&w=1920&q=75",
            link: "https://www.esquinadelcodigo.com/redragon-kumara-k552-review"
        },
        {
            id: 2,
            titulo: "Logitech G733 Lightspeed Review en Español (Análisis completo)",
            descripcion: "Tenemos con nosotros los auriculares gaming Logitech G733 Lightspeed, y no te fíes de su diseño simple y su tierno color, porque su calidad de sonido y prestaciones te van a sorprender. Es lo que ocurre cuando estamos ante una de las mejores marcas de periféricos, que nunca suele fallar y ésta no será la excepción.",
            imagen: "https://www.profesionalreview.com/wp-content/uploads/2020/11/Logitech-G733-Review10-300x200.jpg",
            link: "https://www.profesionalreview.com/2020/11/26/logitech-g733-lightspeed-review/"
        },
        {
            id: 3,
            titulo: "Razer Viper V3 HYPERSPEED Review en Español (Análisis completo)",
            descripcion: "El Razer Viper V3 HYPERSPEED es la nueva propuesta de la marca pensando en quienes buscan un ratón inalámbrico gaming con una alta ergonomía y calidad, latencias reducidas y una alta autonomía. En esta propuesta, dejan de lado características estéticas como el RGB para dar el protagonismo a lo que realmente importa.",
            imagen: "https://www.profesionalreview.com/wp-content/uploads/2023/09/Razer-Viper-V3-Hyperspeed-Review-52-768x576.jpg",
            link: "https://www.profesionalreview.com/2023/09/18/razer-viper-v3-hyperspeed-review/"
        },
        {
            id: 4,
            titulo: "Mejores monitores del mercado",
            descripcion: "Si quieres saber cuáles son los mejores monitores del mercado, nosotros te ofrecemos esta guía completamente actualizada con los que, a nuestro parecer podrían ser las mejores opciones. Elegir un buen monitor no es tarea fácil, ya que muchos parámetros deben ser considerados, por ejemplo, tiempo de panel; IPS, VA, TN, su tasa de refresco, si es para jugar o para diseño, y bastante más cuestiones. Y es por ello que te ofrecemos esta guía que actualizaremos con frecuencia con los mejores monitores del momento para PC, así que, ¡vamos allá!",
            imagen: "https://http2.mlstatic.com/D_Q_NP_2X_683645-MLC93451938925_092025-AB.webp",
            link: "https://www.profesionalreview.com/perifericos/mejores-monitores/"
        }
    ];

    return (
        <>
            <div className='container mt-5'>
                <h1 className='display-4 text-neon'>Bienvenido a Tienda Innova</h1>
                <p className='text-white'>Demo para la Evaluación.</p>

                {/* Sección de Blogs de Periféricos */}
                <section className="mt-5">
                    <h2 className="display-10 text-neon">Blogs sobre Periféricos</h2>
                    <div className="row">
                        {blogs.map(blog => (
                            <div key={blog.id} className="col-md-6 col-lg-3 mb-4">
                                <div className="card blog-card h-100 shadow-sm">
                                    <img
                                        src={blog.imagen}
                                        className="card-img-top"
                                        alt={blog.titulo}
                                        style={{ height: '180px', objectFit: 'cover' }}
                                    />
                                    <div className="card-body d-flex flex-column">
                                        <h5 className="card-title">{blog.titulo}</h5>
                                        <p className="card-text">{blog.descripcion}</p>
                                        <Link to={blog.link} className="btn btn-primary mt-auto">
                                            Leer más
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </section>
            </div>

            <Footer />
        </>
    );
}
