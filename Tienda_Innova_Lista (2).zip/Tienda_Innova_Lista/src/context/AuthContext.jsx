import React,{createContext,useContext,useEffect,useState} from "react";
import { createUser, findUserByEmail, findUserById, setSession, clearSession, getSession, updateUser } from "../utils/fakeDB";
const AuthContext=createContext(); export function useAuth(){return useContext(AuthContext);}
async function hashPassword(password){ const enc=new TextEncoder(); const data=enc.encode(password); const buf=await crypto.subtle.digest("SHA-256", data); return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,"0")).join(""); }
export function AuthProvider({children}){ const [user,setUser]=useState(null); const [loading,setLoading]=useState(true);
useEffect(()=>{ const s=getSession(); if(s&&s.userId){ const u=findUserById(s.userId); if(u) setUser(u);} setLoading(false); },[]);
async function register({name,email,password,address}){ const id=`u_${Date.now()}_${Math.floor(Math.random()*1000)}`; const passwordHash=await hashPassword(password); const newUser=createUser({id,name,email,passwordHash,address}); setSession(newUser.id); setUser(newUser); return newUser; }
async function login({email,password}){ const u=findUserByEmail(email); if(!u) throw new Error("Usuario no existe"); const passwordHash=await hashPassword(password); if(u.passwordHash!==passwordHash) throw new Error("Contraseña incorrecta"); setSession(u.id); setUser(u); return u; }
function logout(){ clearSession(); setUser(null); }
async function updateProfile(patch){ if(!user) throw new Error("No autenticado"); const updated=updateUser(user.id,patch); setUser(updated); return updated; }
return <AuthContext.Provider value={{user,loading,register,login,logout,updateProfile}}>{children}</AuthContext.Provider>; }
