import React from "react";

export default function Footer() {
  return (
    <footer className="bg-dark text-light py-4 mt-5">
      <div className="container d-flex flex-wrap justify-content-between">
        {/* Columna 1: Información de la Tienda */}
        <div className="col-md-4 mb-3">
          <h5>Tienda Innova</h5>
          <p className="mb-0">Tu destino para productos innovadores y de calidad.</p>
        </div>
        
        {/* Columna 2: Enlaces Principales */}
        <div className="col-md-2 mb-3">
          <h6>Tienda</h6>
          <ul className="list-unstyled mb-0">
            <li><a className="text-light text-decoration-none" href="/">Home</a></li>
            <li><a className="text-light text-decoration-none" href="/productos">Productos</a></li>
            <li><a className="text-light text-decoration-none" href="/ofertas">Ofertas</a></li>
            <li><a className="text-light text-decoration-none" href="/carrito">Carrito</a></li>
          </ul>
        </div>

        {/* Columna 3: Información y Cuentas */}
        <div className="col-md-2 mb-3">
          <h6>Compañía</h6>
          <ul className="list-unstyled mb-0">
            <li><a className="text-light text-decoration-none" href="/nosotros">Nosotros</a></li>
            <li><a className="text-light text-decoration-none" href="/contacto">Contacto</a></li>
            <li><a className="text-light text-decoration-none" href="/login">Login</a></li>
            <li><a className="text-light text-decoration-none" href="/register">Register</a></li>
          </ul>
        </div>

        {/* Columna 4: Enlaces Administrativos (Opcional/Seguridad) */}
        <div className="col-md-2 mb-3">
          <h6>Legal y Admin</h6>
          <ul className="list-unstyled mb-0">
            <li><a className="text-light text-decoration-none" href="#">Política de Privacidad</a></li>
            <li><a className="text-light text-decoration-none" href="#">Términos de Servicio</a></li>
          </ul>
        </div>

      </div>
      <div className="text-center mt-4 pt-3 border-top border-secondary">
        <small>&copy; 2025 Tienda Innova. Todos los derechos reservados.</small>
      </div>
    </footer>
  );
}