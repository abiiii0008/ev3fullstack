
import React from "react";
import { Link, NavLink } from "react-router-dom";

export default function Header() {
  return (
    <header className="bg-light py-2 shadow-sm">
      <div className="container d-flex align-items-center justify-content-between">
        <Link className="d-flex align-items-center text-decoration-none" to="/">
          <img src="/img/logo.png" alt="logo" style={{height:48, marginRight:10}} />
          <h1 className="h5 m-0">Tienda Innova</h1>
        </Link>

        <nav>
          <ul className="nav">
            <li className="nav-item">
              <NavLink to="/" className={({isActive})=> "nav-link"+(isActive?" active":"")} end>Inicio</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/productos" className={({isActive})=> "nav-link"+(isActive?" active":"")}>Productos</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/nosotros" className={({isActive})=> "nav-link"+(isActive?" active":"")}>Nosotros</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/contacto" className={({isActive})=> "nav-link"+(isActive?" active":"")}>Contacto</NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/carrito" className={({isActive})=> "nav-link"+(isActive?" active":"")}>
                <i className="fas fa-shopping-cart"></i> Carrito
              </NavLink>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
