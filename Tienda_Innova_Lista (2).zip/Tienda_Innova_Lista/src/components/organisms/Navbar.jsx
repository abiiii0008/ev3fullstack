// src/components/organisms/Navbar.jsx
import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { useCart } from "../../context/CartContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const { count } = useCart();
  return (
    <nav className="navbar navbar-expand-lg navbar-dark header-neon">
      <div className="container">
        <Link className="navbar-brand d-flex align-items-center" to="/">
          <img src="/images/logo-tienda-innova.png" alt="Tienda Innova" style={{height:36, marginRight:10}}/>
          <span className="brand-title">Tienda Innova</span>
        </Link>

        <div className="d-flex gap-2 align-items-center">
          <Link className="nav-link" to="/productos">Productos</Link>
          <Link className="nav-link" to="/carrito">Carrito {count > 0 && <span className="badge bg-danger ms-1">{count}</span>}</Link>
          <Link className="nav-link" to="/nosotros">Nosotros</Link>
          <Link className="nav-link" to="/contacto">Contacto</Link>

          {user ? (
            <>
              <span className="me-2 text-neon">Hola, {user.name}</span>
              <button className="btn btn-outline-light btn-sm" onClick={logout}>Cerrar sesión</button>
            </>
          ) : (
            <>
              <Link className="btn btn-outline-light btn-sm me-2" to="/login">Entrar</Link>
              <Link className="btn btn-danger btn-sm" to="/register">Registrarse</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
