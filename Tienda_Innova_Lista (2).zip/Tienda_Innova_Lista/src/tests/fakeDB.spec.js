import { getAllUsers, createUser, findUserByEmail, findUserById, updateUser, setSession, getSession, clearSession } from '../utils/fakeDB';

describe('fakeDB basic operations', () => {
  beforeEach(() => {
    // clear storage before each test
    localStorage.clear();
  });

  it('should create and find a user by email', () => {
    const user = createUser({ id: 'u1', name: 'Test', email: 'a@b.com', passwordHash: 'hash', address: {} });
    expect(user.email).toBe('a@b.com');
    const found = findUserByEmail('a@b.com');
    expect(found).not.toBeNull();
    expect(found.id).toBe('u1');
  });

  it('should not allow duplicate emails', () => {
    createUser({ id: 'u2', name: 'T', email: 'dup@x.com', passwordHash: 'h', address: {} });
    let threw = false;
    try {
      createUser({ id: 'u3', name: 'T2', email: 'dup@x.com', passwordHash: 'h2', address: {} });
    } catch (e) {
      threw = true;
    }
    expect(threw).toBeTrue();
  });

  it('should update a user', () => {
    createUser({ id: 'u4', name: 'Old', email: 'old@x.com', passwordHash: 'h', address: {} });
    const updated = updateUser('u4', { name: 'New' });
    expect(updated.name).toBe('New');
  });

  it('should manage session', () => {
    setSession('u4');
    const s = getSession();
    expect(s.userId).toBe('u4');
    clearSession();
    expect(getSession()).toBeNull();
  });
});
