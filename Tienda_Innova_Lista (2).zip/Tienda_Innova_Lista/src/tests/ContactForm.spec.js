
import React from 'react';
import { createRoot } from 'react-dom/client';
import ContactForm from '../shared/ContactForm';

describe('ContactForm', () => {
  let container;
  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
    const root = createRoot(container);
    root.render(React.createElement(ContactForm));
  });
  afterEach(() => {
    document.body.removeChild(container);
    container = null;
  });

  it('renders form inputs', () => {
    expect(container.querySelector('input[name="name"]')).not.toBeNull();
    expect(container.querySelector('input[name="email"]')).not.toBeNull();
    expect(container.querySelector('textarea[name="message"]')).not.toBeNull();
  });

  it('shows validation errors when submitting empty', () => {
    const btn = container.querySelector('button[type="submit"]');
    btn.click();
    // validation adds small text-danger elements
    expect(container.querySelectorAll('.text-danger').length).toBeGreaterThan(0);
  });
});
