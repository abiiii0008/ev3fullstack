// fakeDB.js
const USERS_KEY = "tiendainnova_users";
const SESSION_KEY = "tiendainnova_session";
export function getAllUsers(){ const raw = localStorage.getItem(USERS_KEY); return raw?JSON.parse(raw):[]; }
function saveAllUsers(u){ localStorage.setItem(USERS_KEY, JSON.stringify(u)); }
export function createUser({id,name,email,passwordHash,address={}}){ const users=getAllUsers(); if(users.find(x=>x.email.toLowerCase()===email.toLowerCase())) throw new Error("Email ya registrado"); const nu={id,name,email,passwordHash,address}; users.push(nu); saveAllUsers(users); return nu;}
export function findUserByEmail(email){ const users=getAllUsers(); return users.find(u=>u.email.toLowerCase()===email.toLowerCase())||null; }
export function findUserById(id){ const users=getAllUsers(); return users.find(u=>u.id===id)||null; }
export function updateUser(id,patch){ const users=getAllUsers(); const i=users.findIndex(u=>u.id===id); if(i===-1) throw new Error("Usuario no encontrado"); users[i]={...users[i],...patch}; saveAllUsers(users); return users[i]; }
export function setSession(userId){ localStorage.setItem(SESSION_KEY, JSON.stringify({userId})); }
export function clearSession(){ localStorage.removeItem(SESSION_KEY); }
export function getSession(){ const raw=localStorage.getItem(SESSION_KEY); return raw?JSON.parse(raw):null; }
