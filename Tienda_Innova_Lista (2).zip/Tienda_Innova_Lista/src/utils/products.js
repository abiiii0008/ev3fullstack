// src/utils/products.js - simulated product list
const PRODUCTS = [
  { id: 'p1', name: 'Audifonos inalambricos Logitech G733 con micrófono Negro', price: 174990, image: 'https://cdnx.jumpseller.com/killstore/image/47389742/resize/610/610?1718121116', category: 'Audio', description: 'cuenta con sonido envolvente 7.1 y conexión inalámbrica. Estos audífonos están diseñados para gaming intenso y ofrecen un gran confort para largas sesiones de juego.' },
  { id: 'p2', name: 'Kumara K552', price: 36990, image: 'https://media.spdigital.cl/thumbnails/products/8cj7010s_6fe796b6_thumbnail_512.png', category: 'Periféricos', description: 'El Kumara es un teclado mecánico TKL (sin pad numérico);compacto, pero ampliamente funcional. Y fuerte—muy fuerte—, gracias a que su estructura estáreforzada con acero. Es virtualmente irrompibley tiene una durabilidad extraordinaria.' },
  { id: 'p3', name: 'razer viper v3 hyperspeed', price: 99990, image: 'https://http2.mlstatic.com/D_NQ_NP_654276-MLA81204038176_122024-O.webp', category: 'Periféricos', description: 'Mouse con sensor de alta precisión' },
  { id: 'p4', name: 'Monitor 144Hz 24"', price: 94990, image: 'https://http2.mlstatic.com/D_Q_NP_2X_683645-MLC93451938925_092025-AB.webp', category: 'Monitores', description: 'Monitor FullHD 144Hz con Freesync' }
];

export function getAllProducts() {
  return PRODUCTS;
}
export function findProductById(id) {
  return PRODUCTS.find(p => p.id === id) || null;
}
