
# ERS - Tienda Innova (V2)

## Resumen
Migración del frontend estático HTML/CSS/JS a una aplicación React con Bootstrap.
Objetivos: componentes reutilizables, persistencia local (data.js), vistas adicionales, y tests unitarios.

## Requerimientos funcionales (selección)
- RF1: Ver listado de productos.
- RF2: Agregar/editar/eliminar productos (panel admin).
- RF3: Añadir productos al carrito y persistir.
- RF4: Checkout con formulario y validación.
- RF5: Formulario de contacto con validaciones.
- RF6: Vistas: Home, Productos, Categorías, Carrito, Checkout, Ofertas, Admin, Contacto.

## Requerimientos no funcionales
- RNF1: Diseño responsivo con Bootstrap.
- RNF2: Pruebas unitarias con Jasmine + Karma.
- RNF3: Código modular y documentado.

## Arquitectura y componentes
- components/: Header, Footer
- pages/: Vistas
- data/: Persistencia (localStorage)
- shared/: Componentes reutilizables (ContactForm)

## Persistencia
Se utiliza localStorage con clave `miTienda:products` para productos y `miTienda:cart` para carrito.

