const express = require("express");
const cors = require("cors");

const app = express();   // ⬅️ AQUÍ SE CREA "app"

app.use(cors());
app.use(express.json());

// Base de datos temporal (solo para pruebas)
let productos = [
    { id: 1, nombre: "Producto 1", precio: 1000 },
    { id: 2, nombre: "Producto 2", precio: 2000 }
];

// GET: obtener productos
app.get("/api/productos", (req, res) => {
  res.json(productos);
});

// POST: agregar producto
app.post("/api/productos", (req, res) => {
  const nuevo = {
    id: productos.length + 1,
    nombre: req.body.nombre,
    precio: req.body.precio
  };

  productos.push(nuevo);
  res.json({ mensaje: "Producto agregado", producto: nuevo });
});

app.listen(3001, () => {
  console.log("🔥 Backend funcionando en http://localhost:3001");
});
