# Coverage Summary (objetivo)

Objetivo de cobertura para la entrega:
- Componentes clave: Login, Register, RequireAuth, Checkout -> cobertura objetivo >= 60%
- Utilidades: fakeDB.js -> pruebas incluidas
- Nota: Se agregaron tests para utilidades y guía para ejecutar pruebas y generar cobertura.
